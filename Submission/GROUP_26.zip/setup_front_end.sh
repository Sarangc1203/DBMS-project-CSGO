# !/bin/sh

pip3 install Flask
pip3 install psycopg2